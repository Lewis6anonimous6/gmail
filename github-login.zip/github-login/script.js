/* ================================================================
   script.js — Google Sign-In replica logic
   100% vanilla JS — no frameworks, no build step
   Works on GitHub Pages, double-click open, everywhere
   ================================================================ */

/* ── App state (in-memory only, never sent anywhere) ── */
let userEmail = '';

/* ── Spinner SVG string ── */
const SPINNER_SVG = `
  <svg class="spinner" xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24" fill="none" stroke="#fff"
    stroke-width="2.5" width="18" height="18" aria-hidden="true">
    <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83
             M16.24 16.24l2.83 2.83M2 12h4M18 12h4
             M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
  </svg>`;

/* ════════════════════════════════════════════════
   FIELD: floating label behaviour
   ════════════════════════════════════════════════ */
function initField(inputId, boxId) {
  const input = document.getElementById(inputId);
  const box   = document.getElementById(boxId);
  if (!input || !box) return;

  function update() {
    box.classList.toggle('filled', input.value.length > 0);
  }

  input.addEventListener('focus', () => {
    box.classList.add('focused');
    update();
  });

  input.addEventListener('blur', () => {
    box.classList.remove('focused');
    update();
  });

  input.addEventListener('input', () => {
    // Clear error state on typing
    box.classList.remove('invalid');
    const wrap = box.closest('.field-wrap');
    if (wrap) wrap.classList.remove('error');
    const errEl = wrap ? wrap.querySelector('.field-error') : null;
    if (errEl) errEl.classList.add('hidden');
    update();
  });

  // Allow Enter to proceed
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      if (inputId === 'f1-email') phase1Next();
      if (inputId === 'f2-pw')    phase2Next();
    }
  });
}

/* ════════════════════════════════════════════════
   VALIDATION
   ════════════════════════════════════════════════ */
function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

function showFieldError(wrapId, boxId, errorId, message) {
  const wrap  = document.getElementById(wrapId);
  const box   = document.getElementById(boxId);
  const errEl = document.getElementById(errorId);
  if (wrap)  wrap.classList.add('error');
  if (box)   box.classList.add('invalid');
  if (errEl) { errEl.textContent = message; errEl.classList.remove('hidden'); }
}

function clearFieldError(wrapId, boxId, errorId) {
  const wrap  = document.getElementById(wrapId);
  const box   = document.getElementById(boxId);
  const errEl = document.getElementById(errorId);
  if (wrap)  wrap.classList.remove('error');
  if (box)   box.classList.remove('invalid');
  if (errEl) errEl.classList.add('hidden');
}

/* ════════════════════════════════════════════════
   PHASE NAVIGATION
   ════════════════════════════════════════════════ */
function showPhase(n) {
  const phases = ['phase1', 'phase2', 'phase3', 'phase4'];
  phases.forEach((id, index) => {
    const el = document.getElementById(id);
    if (el) el.classList.toggle('hidden', index + 1 !== n);
  });
  // Focus first input of new phase
  setTimeout(() => {
    if (n === 1) document.getElementById('f1-email')?.focus();
    if (n === 2) document.getElementById('f2-pw')?.focus();
  }, 80);
}

/* ════════════════════════════════════════════════
   PHASE 1 → 2
   ════════════════════════════════════════════════ */
function phase1Next() {
  const emailEl = document.getElementById('f1-email');
  const email   = emailEl ? emailEl.value.trim() : '';

  if (!email) {
    showFieldError('f1-wrap', 'f1-box', 'f1-error', 'Enter an email or phone number.');
    emailEl?.focus();
    return;
  }
  if (!isValidEmail(email)) {
    showFieldError('f1-wrap', 'f1-box', 'f1-error', 'Enter a valid email address.');
    emailEl?.focus();
    return;
  }

  clearFieldError('f1-wrap', 'f1-box', 'f1-error');

  // Store email in memory — used to display in following phases
  userEmail = email;

  // Propagate email to all chips and success screen
  const chipEls = ['chip-email2', 'chip-email3', 'success-email'];
  chipEls.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = userEmail;
  });

  showPhase(2);
}

/* ════════════════════════════════════════════════
   PHASE 2 → 3  (with loading animation)
   ════════════════════════════════════════════════ */
function phase2Next() {
  const pwEl = document.getElementById('f2-pw');
  const pw   = pwEl ? pwEl.value : '';

  if (!pw) {
    showFieldError('f2-wrap', 'f2-box', 'f2-error', 'Enter a password.');
    pwEl?.focus();
    return;
  }

  clearFieldError('f2-wrap', 'f2-box', 'f2-error');

  const btn = document.getElementById('btn2');
  if (!btn) return;

  // Show spinner
  btn.disabled  = true;
  btn.innerHTML = SPINNER_SVG;

  setTimeout(() => {
    btn.disabled  = false;
    btn.innerHTML = 'Next';
    showPhase(3);
  }, 900);
}

/* ════════════════════════════════════════════════
   PHASE 3 → 4  (with loading animation)
   ════════════════════════════════════════════════ */
function phase3Next() {
  const btn = document.getElementById('btn3');
  if (!btn) return;

  btn.disabled  = true;
  btn.innerHTML = SPINNER_SVG;

  setTimeout(() => {
    btn.disabled  = false;
    btn.innerHTML = 'Next';
    showPhase(4);
  }, 1000);
}

/* ════════════════════════════════════════════════
   SHOW PASSWORD TOGGLE
   ════════════════════════════════════════════════ */
function togglePw() {
  const cb = document.getElementById('show-pw-cb');
  const pw = document.getElementById('f2-pw');
  if (cb && pw) {
    pw.type = cb.checked ? 'text' : 'password';
  }
}

/* ════════════════════════════════════════════════
   RESTART (sign out)
   ════════════════════════════════════════════════ */
function restart() {
  userEmail = '';

  // Clear inputs
  const emailEl = document.getElementById('f1-email');
  const pwEl    = document.getElementById('f2-pw');
  const cb      = document.getElementById('show-pw-cb');
  if (emailEl) emailEl.value = '';
  if (pwEl)    { pwEl.value = ''; pwEl.type = 'password'; }
  if (cb)      cb.checked = false;

  // Reset field box states
  ['f1-box', 'f2-box'].forEach(id => {
    const box = document.getElementById(id);
    if (box) box.classList.remove('focused', 'filled', 'invalid');
  });
  ['f1-wrap', 'f2-wrap'].forEach(id => {
    const wrap = document.getElementById(id);
    if (wrap) wrap.classList.remove('error');
  });
  ['f1-error', 'f2-error'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.add('hidden');
  });

  showPhase(1);
}

/* ════════════════════════════════════════════════
   INIT
   ════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  initField('f1-email', 'f1-box');
  initField('f2-pw',    'f2-box');

  // Keyboard accessibility for email chips
  document.querySelectorAll('.email-chip[role="button"]').forEach(chip => {
    chip.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') showPhase(1);
    });
  });
});
