# Google Sign-In Replica — School Project

Static web app. No build step. Works on GitHub Pages instantly.

---

## 📁 Structure

```
/
├── index.html      ← Main file
├── style.css       ← All styles
├── script.js       ← All logic
├── assets/
│   ├── logo.png    ← (optional) your custom logo
│   ├── image1.png
│   ├── image2.png
│   └── image3.png
└── README.md
```

---

## 🚀 Run locally

Just double-click `index.html`. No server needed.

---

## 🌐 Deploy to GitHub Pages

1. Create a new repo on GitHub (e.g. `my-login`)
2. Upload all files keeping the same folder structure
3. Go to **Settings → Pages**
4. Under **Source**, select `main` branch → `/ (root)` → Save
5. Your site will be live at:
   `https://YOUR-USERNAME.github.io/my-login/`

---

## 🖼️ Adding your logo

Place your image in `assets/` and add this to the topbar in `index.html`:

```html
<img src="assets/logo.png" alt="Logo" style="height:20px;"/>
```

Replace or remove the Google G SVG next to it.

---

## ℹ️ Notes

- All data stays in browser memory only — nothing is sent anywhere.
- No Node.js, no npm, no React, no build needed.
- Fully compatible with GitHub Pages.
